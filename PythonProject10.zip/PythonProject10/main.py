import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('ecommerce_estatistica.csv')

print(df.columns)
print(df.info())
print(df.describe())
print(df.isnull().sum())

# Gráfico de Histograma
plt.figure(figsize=(8,5))
plt.hist(df["Preço"], bins=30)
plt.title("Histograma de Preço")
plt.xlabel("Preço (R$)")
plt.ylabel("Frequência")
plt.show()

# Gráfico de Dispersão
plt.figure(figsize=(7,5))
plt.scatter(df["N_Avaliações"], df["Preço"], alpha=0.6)
plt.title("Dispersão: Preço X Número de Avaliações")
plt.xlabel("Número de Avaliações")
plt.ylabel("Preço (R$)")
plt.show()

# Mapa de Calor
corr = df[["Preço", "N_Avaliações"]].corr()
plt.figure(figsize=(10,8))
sns.heatmap(corr, annot=True, cmap="coolwarm")
plt.title("Correlação entre Preço e Número de Avaliações")
plt.show()

# Gráfico de Barras
plt.figure(figsize=(10,6))
df['Marca'].value_counts().head(10).plot(kind='bar')
plt.title("Marca")
plt.xlabel("Marca")
plt.ylabel("Qtd_Vendidos")
plt.xticks(rotation=45)
plt.show()

# Gráfico de Pizza
plt.figure(figsize=(10,6))
df["Gênero"].value_counts().head(7).plot(kind='pie', autopct='%.1f%%')
plt.title('Distribuição por Gênero')
plt.ylabel("")
plt.show()

# Gráfico de Densidade
plt.figure(figsize=(10,6))
plt.hexbin(df['Preço'], df['Nota'], gridsize=30, cmap='Blues')
plt.colorbar(label = 'Contagem dentro do bin')
plt.xlabel('Preço')
plt.ylabel('Nota')
plt.title('Dispersão de Preço e Nota')
plt.show()

# Gráfico de Regressão
plt.figure(figsize=(8,6))
sns.regplot(x="N_Avaliações", y="Preço", data=df, scatter_kws={"alpha":0.5})
plt.title("Regressão Linear - Preço vs Número de Avaliações")
plt.xlabel("Número de Avaliações")
plt.ylabel("Preço (R$)")
plt.show()